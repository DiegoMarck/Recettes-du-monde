<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'lu', 'mu', 'mao', 'tong', 'rong', 'chang', 'pu', 'lu', 'zhan', 'sao', 'zhan', 'meng', 'lu', 'qu', 'die', 'shi',
  0x10 => 'di', 'min', 'jue', 'mang', 'qi', 'pie', 'nai', 'qi', 'dao', 'xian', 'chuan', 'fen', 'yang', 'nei', 'bin', 'fu',
  0x20 => 'shen', 'dong', 'qing', 'qi', 'yin', 'xi', 'hai', 'yang', 'an', 'ya', 'ke', 'qing', 'ya', 'dong', 'dan', 'lu',
  0x30 => 'qing', 'yang', 'yun', 'yun', 'shui', 'shui', 'zheng', 'bing', 'yong', 'dang', 'shui', 'le', 'ni', 'tun', 'fan', 'gui',
  0x40 => 'ting', 'zhi', 'qiu', 'bin', 'ze', 'mian', 'cuan', 'hui', 'diao', 'han', 'cha', 'zhuo', 'chuan', 'wan', 'fan', 'da',
  0x50 => 'xi', 'tuo', 'mang', 'qiu', 'qi', 'shan', 'pin', 'han', 'qian', 'wu', 'wu', 'xun', 'si', 'ru', 'gong', 'jiang',
  0x60 => 'chi', 'wu', 'tu', 'jiu', 'tang', 'zhi', 'zhi', 'qian', 'mi', 'gu', 'wang', 'jing', 'jing', 'rui', 'jun', 'hong',
  0x70 => 'tai', 'quan', 'ji', 'bian', 'bian', 'gan', 'wen', 'zhong', 'fang', 'xiong', 'jue', 'hu', 'niu', 'qi', 'fen', 'xu',
  0x80 => 'xu', 'qin', 'yi', 'wo', 'yun', 'yuan', 'hang', 'yan', 'chen', 'chen', 'dan', 'you', 'dun', 'hu', 'huo', 'qi',
  0x90 => 'mu', 'nu', 'mei', 'da', 'mian', 'mi', 'chong', 'pang', 'bi', 'sha', 'zhi', 'pei', 'pan', 'zhui', 'za', 'gou',
  0xA0 => 'liu', 'mei', 'ze', 'feng', 'ou', 'li', 'lun', 'cang', 'feng', 'wei', 'hu', 'mo', 'mei', 'shu', 'ju', 'zan',
  0xB0 => 'tuo', 'tuo', 'tuo', 'he', 'li', 'mi', 'yi', 'fa', 'fei', 'you', 'tian', 'zhi', 'zhao', 'gu', 'zhan', 'yan',
  0xC0 => 'si', 'kuang', 'jiong', 'ju', 'xie', 'qiu', 'yi', 'jia', 'zhong', 'quan', 'po', 'hui', 'mi', 'ben', 'ze', 'zhu',
  0xD0 => 'le', 'you', 'gu', 'hong', 'gan', 'fa', 'mao', 'si', 'hu', 'ping', 'ci', 'fan', 'zhi', 'su', 'ning', 'cheng',
  0xE0 => 'ling', 'pao', 'bo', 'qi', 'si', 'ni', 'ju', 'sa', 'zhu', 'sheng', 'lei', 'xuan', 'jue', 'fu', 'pan', 'min',
  0xF0 => 'tai', 'yang', 'ji', 'yong', 'guan', 'beng', 'xue', 'long', 'lu', 'dan', 'luo', 'xie', 'po', 'ze', 'jing', 'yin',
];
